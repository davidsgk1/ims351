//
//  ViewController.swift
//  Run Miami
//
//  Created by Keegan Davidson on 2/22/18.
//  Copyright © 2018 Keegan Davidson. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var backgroundImage: UIImageView!
    @IBOutlet weak var dateLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        backgroundImage.image = #imageLiteral(resourceName: "miamiRec")
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .none
        var timeString = (dateFormatter.string(from: NSDate() as Date))
        
        dateLabel.text = timeString
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

