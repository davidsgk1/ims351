//
//  RunViewController.swift
//  Run Miami
//
//  Created by Keegan Davidson on 2/22/18.
//  Copyright © 2018 Keegan Davidson. All rights reserved.
//

import UIKit

class RunViewController: UIViewController {
    
    //Button inputs
    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var button2: UIButton!
    @IBOutlet weak var button3: UIButton!
    @IBOutlet weak var button4: UIButton!
    
    var lane = 0
    
    @IBAction func laneOne(_ sender: Any) {
        if button1.backgroundColor == UIColor.gray {
            
            button1.backgroundColor = UIColor.red
            button2.backgroundColor = UIColor.gray
            button3.backgroundColor = UIColor.gray
            button4.backgroundColor = UIColor.gray
            
            lane = 1
        }
    }
    
    @IBAction func laneTwo(_ sender: Any) {
        if button2.backgroundColor == UIColor.gray {
            
            button2.backgroundColor = UIColor.red
            button3.backgroundColor = UIColor.gray
            button4.backgroundColor = UIColor.gray
            button1.backgroundColor = UIColor.gray
            
            lane = 2
        }
    }
    @IBAction func laneThree(_ sender: Any) {
        if button3.backgroundColor == UIColor.gray {
            
            button3.backgroundColor = UIColor.red
            button4.backgroundColor = UIColor.gray
            button1.backgroundColor = UIColor.gray
            button2.backgroundColor = UIColor.gray
            
            lane = 3
        }
    }
    @IBAction func laneFour(_ sender: Any) {
        if button4.backgroundColor == UIColor.gray {
            
            button4.backgroundColor = UIColor.red
            button1.backgroundColor = UIColor.gray
            button2.backgroundColor = UIColor.gray
            button3.backgroundColor = UIColor.gray
            
            lane = 4
        }
    }
 
    @IBOutlet weak var distanceNumber: UILabel!
    @IBOutlet weak var distanceStepper: UIStepper!
    @IBAction func distanceIncrement(_ sender: Any) {
        var distance = Int(distanceStepper.value)
        
        if (distance > 26) {
            distance = 0
            print("there is no way anyone is using this app to run more than a marathon, sorry")
            distanceStepper.value = 0
        
        }
        
        distance = Int(distanceStepper.value)
        distanceNumber.text = String(distance) + " miles"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        button1.backgroundColor = UIColor.gray
        button2.backgroundColor = UIColor.gray
        button3.backgroundColor = UIColor.gray
        button4.backgroundColor = UIColor.gray
        
        var mainColor = hexStringToUIColor(hex: "E74C3C")
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "gotoDuringRun" {
            let destination = segue.destination as? duringRunViewController
            
            destination?.lane = lane
            destination?.distance = Double(distanceStepper.value)
        }
    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
