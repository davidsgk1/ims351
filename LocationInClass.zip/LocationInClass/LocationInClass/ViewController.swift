//
//  ViewController.swift
//  LocationInClass
//
//  Created by Keegan Davidson on 4/5/18.
//  Copyright © 2018 Keegan Davidson. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {

    @IBOutlet weak var columbusDist: UILabel!
    @IBOutlet weak var philmontDist: UILabel!
    @IBOutlet weak var florenceDist: UILabel!
    @IBOutlet weak var albDist: UILabel!
    @IBOutlet weak var orlandoDist: UILabel!
    
    
    let locationManager = CLLocationManager();
    var allLocations = [CLLocation]()
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
//        locationManager.distanceFilter = 100.0
        
        locationManager.delegate = self
        locationManager.requestAlwaysAuthorization()
        locationManager.startUpdatingLocation();
        locationManager.startMonitoringSignificantLocationChanges();
        
        print(locationManager.location)
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let mostRecentLocation = locations.last!
        
        let columbusLoc = CLLocation(latitude: 39.9814305, longitude: -83.2715622)
        let philmontLoc = CLLocation(latitude: 36.4540472, longitude: -104.9602407)
        let florenceLoc = CLLocation(latitude: 43.7799368, longitude: 11.1709282)
        let albLoc = CLLocation(latitude: 35.0823294, longitude: -106.8165638)
        let orlandoLoc = CLLocation(latitude: 28.4810971, longitude: -81.508835)
        
        columbusDist.text = String(Int(mostRecentLocation.distance(from: columbusLoc) / 1000))
        philmontDist.text = String(Int(mostRecentLocation.distance(from: philmontLoc) / 1000))
        florenceDist.text = String(Int(mostRecentLocation.distance(from: florenceLoc) / 1000))
        albDist.text = String(Int(mostRecentLocation.distance(from: albLoc) / 1000))
        orlandoDist.text = String(Int(mostRecentLocation.distance(from: orlandoLoc) / 1000))
        
        
//        if(allLocations.count > 1) {
//            let distanceBetweenLastTwoLocations = mostRecentLocation.distance (from: allLocations.last!)
//            print(distanceBetweenLastTwoLocations)
//        }
        
        allLocations.append(mostRecentLocation)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

