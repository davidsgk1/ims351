//
//  duringRunViewController.swift
//  Run Miami
//
//  Created by Keegan Davidson on 2/27/18.
//  Copyright © 2018 Keegan Davidson. All rights reserved.
//


//QUESITONS FOR ARTIE:
//HOW DO I TRIGGER SEGUES PROGRAMATICALLY?
//WHY WON'T LAPSRAN SEND CORRECTLY?
//HOW DO I RUN MILLISECONDS ON MY TIMER?
//CUSTOM STYLES ON THE NAVBAR?

import UIKit

class duringRunViewController: UIViewController {
    
    @IBOutlet weak var lapButton: UIButton!
    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var paceLabel: UILabel!
    @IBOutlet weak var mileLabel: UILabel!
    @IBOutlet weak var lastLapLabel: UILabel!
    @IBOutlet weak var lapLabel: UILabel!
    
    //Pulling variables from the segue
    var lane = 0
    var distance = 0.0
    var currentRun = RunObject()
    
    //Instance variables for the class
    var indvLaps = [Double]()  //An array for holding each lap
    var lapsRan = 0;
    
    
    func loadRun() {
        currentRun = RunObject(runDate: NSDate() as Date, runTime: timeString(time: TimeInterval(seconds)), lapsRan: lapsRan, lane: lane, goalDistance: getLaps(lane: lane, distance: distance), totalTime: 0.0)
        
        currentRun.toString()
        
        //Setting mile label, casting
        mileLabel.text = String("pace - \(distance) miles")
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        runTimer()
        
        //Setting current date values
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .none
        var dateString = (dateFormatter.string(from: NSDate() as Date))
        
        loadRun()
    }
    
    func getLaps(lane:Int, distance:Double) -> Double {
        //setting the necessary amount of laps for a mile, to help find the laps to match the distance
        var totalLaps = 0.0
        var laps = 0.0
        
        switch lane {
        case 1:
            laps = 8
        case 2:
            laps = 8.5
        case 3:
            laps = 8.5
        default:
            laps = 9
        }
        
        totalLaps = Double(laps * distance)
        return totalLaps
    }
    
    var seconds = 0.0
    var timer = Timer()
    var isTimerRunning = false
    
    
    //For working with milliseconds, change time interval to 0.01
    func runTimer() {
        timer = Timer.scheduledTimer(timeInterval: 1, target: self,   selector: (#selector(duringRunViewController.updateTimer)), userInfo: nil, repeats: true)
    }
    
    @objc func updateTimer() {
        seconds += 1
        timerLabel.text = timeString(time: TimeInterval(seconds))
    }
    
    func timeString(time:TimeInterval) -> String {
        let minutes = Int(time) / 60 % 60
        let seconds = Int(time) % 60
        return String(format:"%02i:%02i", minutes, seconds)
    }
    
    @IBAction func lapButtonTapped(_ sender: Any) {
        loadRun()
        
        //Laps ran for this run so far, updating object
        lapsRan += 1;
        currentRun.setLapsRan(laps: lapsRan);
        print("LAPS RAN: " + String(currentRun.lapsRan))
        
        if (lapsRan == Int(currentRun.goalDistance)) {
            performSegue(withIdentifier: "goToFinishRunViewController", sender: self)
            
        }
        var pace = getPace(lap: Double(seconds), goalDistance: getLaps(lane: lane, distance: distance))
        print("Pace")
        print(pace)
        
        paceLabel.text = pace
        lapLabel.text = "Lap " + String(indvLaps.count + 1)
        
        timer.invalidate()
        seconds = 0
        runTimer()
    }
    
    //ends the timer and sends to the next view
    @IBAction func finishButtonTapped(_ sender: UIButton) {
        timer.invalidate()
    }
    
    //Calculates the pace based on the goal distance, updates the pace and lap # labels
    func getPace(lap: Double, goalDistance: Double) -> String {
        
        var avgLap = 0.0
        indvLaps.append(lap)
        
        //Adding and calculating average laps(sum of all time)
        for l in indvLaps {
            avgLap += l
        }
        
        //Setting totalTime in RunObject
        loadRun()
        currentRun.setTotalTime(seconds: avgLap)
        print("TotalTime:")
        print(currentRun.totalTime)
        
        //This would ideally send to the next page if the amount of laps hits the goal distance
        if (Double(indvLaps.count) >= goalDistance) {
            print("run finished!")
            lastLapLabel.text = ""
            timer.invalidate()
        }
        else if (Double(indvLaps.count) == goalDistance - 1.0) {
            lastLapLabel.text = "Last lap!"
        }
        
        avgLap /= Double(indvLaps.count)
        
        
        var paceSeconds = avgLap * goalDistance
        let minutes = Int(paceSeconds) / 60 % 60
        let seconds = Int(paceSeconds) % 60
        return String(format:"%02i:%02i", minutes, seconds)

    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "goToFinishRunViewController" {
            let destination = segue.destination as? finishRunViewController
            
            var sendRun = RunObject(run: currentRun)
            destination?.finishedRun = sendRun
        }
    }
    
    //CHANGE THIS TO SWITCH VIEWS PROGRAMATICALLY ONCE YOU HAVE THE NORMAL SEGUE CODE COMPLETE
//    class SourceViewController: UIViewController {
//        func presentDestinationViewController() {
//            let data = Data()
//            let destinationViewController = DestinationViewController(nibName: "DestinationViewController", bundle: nil)
//            destinationViewController.data = data
//            present(destinationViewController, animated: true, completion: nil)
//        }
//    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
