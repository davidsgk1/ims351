//
//  finishRunViewController.swift
//  Run Miami
//
//  Created by Keegan Davidson on 2/27/18.
//  Copyright © 2018 Keegan Davidson. All rights reserved.
//

import UIKit

class finishRunViewController: UIViewController {
    
    @IBOutlet weak var finalTimeLabel: UILabel!
    @IBOutlet weak var finalDistanceLabel: UILabel!
    @IBOutlet weak var finalRunImage: UIImageView!
    
    var finishedRun = RunObject()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        finalRunImage.image = #imageLiteral(resourceName: "miamiRec")
        print("SEGUE RUN")
        finishedRun.toString()
        let minutes = Int(finishedRun.totalTime) / 60 % 60
        let seconds = Int(finishedRun.totalTime) % 60
        finalTimeLabel.text = String(format:"%02i:%02i", minutes, seconds)
        finalDistanceLabel.text = String(finishedRun.goalDistance) + " Laps"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
