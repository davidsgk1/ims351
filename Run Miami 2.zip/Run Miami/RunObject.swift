//
//  RunObject.swift
//  Run Miami
//
//  Created by Keegan Davidson on 3/8/18.
//  Copyright © 2018 Keegan Davidson. All rights reserved.
//

import UIKit

class RunObject {
    
    var lane:Int //The lane in which the user ran
    var runDate:Date //The date that the run occurred on
    var runTime:String //The amount of time the timer ran for
    var lapsRan:Int //The number of times the user pressed the lap button
    var goalDistance:Double //The goal distance in laps (double)
    var totalTime:Double //The sum of the pace array
    
    //Strict constructor
    init(runDate:Date, runTime:String, lapsRan:Int, lane:Int, goalDistance:Double, totalTime:Double) {
        self.runDate = runDate
        self.runTime = runTime
        self.lapsRan = lapsRan
        self.lane = lane
        self.goalDistance = goalDistance
        self.totalTime = totalTime
    }
    
    //Empty constructor
    init() {
        self.runDate = NSDate() as Date
        self.runTime = ""
        self.lapsRan = 0
        self.lane = 0
        self.goalDistance = 0.0
        self.totalTime = 0.0
    }
    
    //Maybe create a copy constructor to copy the old run object to the new view controller??
    init(run: RunObject) {
        self.runDate = run.runDate
        self.runTime = run.runTime
        self.lapsRan = run.lapsRan
        self.lane = run.lane
        self.goalDistance = run.goalDistance
        self.totalTime = run.totalTime
    }
    
    func toString() {
        print(self.runDate)
        print(self.runTime)
        print(self.lapsRan)
        print(self.lane)
        print(self.goalDistance)
        print(self.totalTime)
    }
    
    func setTotalTime(seconds: Double) {
        self.totalTime = seconds
    }
    
    func setLapsRan(laps: Int) {
        self.lapsRan = laps
    }
}
