//
//  pokemonTableCell.swift
//  Pokemon List
//
//  Created by Kuhn, Artie R Mr. on 2/14/18.
//  Copyright © 2018 artiekuhn. All rights reserved.
//
import UIKit

class pokemonTableCell: UITableViewCell {
    @IBOutlet weak var pokemonImage: UIImageView!
    
    @IBOutlet weak var pokemonLabel: UILabel!
}
