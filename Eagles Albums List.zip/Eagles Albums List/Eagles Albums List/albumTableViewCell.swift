//
//  albumTableViewCell.swift
//  Eagles Albums List
//
//  Created by Keegan Davidson on 2/15/18.
//  Copyright © 2018 Keegan Davidson. All rights reserved.
//

import UIKit

class albumTableViewCell: UITableViewCell {

    @IBOutlet weak var albumPhoto: UIImageView!
    @IBOutlet weak var albumName: UILabel!
    @IBOutlet weak var albumYear: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
