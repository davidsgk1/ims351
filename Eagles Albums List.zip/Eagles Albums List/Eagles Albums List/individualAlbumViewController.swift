//
//  individualAlbumViewController.swift
//  Eagles Albums List
//
//  Created by Keegan Davidson on 2/15/18.
//  Copyright © 2018 Keegan Davidson. All rights reserved.
//

import UIKit

class individualAlbumViewController: UIViewController {

    var albumIndex = 0;
    
    @IBOutlet weak var albumName: UILabel!
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var releaseDate: UILabel!
    @IBOutlet weak var usChart: UILabel!
    @IBOutlet weak var detailImg: UIImageView!
    @IBOutlet weak var albumAbout: UILabel!
    
    var albums = ["eagles", "desperado", "on the border", "one of these nights","hotel california", "the long run", "long road out of eden"]
    
    var labels = ["Asylum", "Asylum", "Asylum", "Asylum", "Asylum", "Asylum", "ERC"]
    
    var date = ["June 17, 1972", "April 17, 1973", "March 22, 1974", "June 10, 1975", "December 8, 1976", "September 24, 1979", "October 29, 1979"]
    
    var chart = ["22", "41", "17", "1", "1", "1", "1"]
    
    var desc = ["Eagles is the debut studio album by the rock band the Eagles. The album was recorded at London's Olympic Studios with producer Glyn Johns and released in 1972. The album was an immediate success for the young band reaching No. 22 on the charts and going platinum.", "Desperado is the second studio album by the American band the Eagles. It was recorded at Island Studios in London, England and released in 1973. The songs on Desperado are based on the themes of the Old West. The band members are featured on the album's cover dressed like an outlaw gang; Desperado remains the only Eagles album where the band members appear on the front cover.", "On the Border is the third studio album by American rock group the Eagles, released in 1974. Apart from two songs produced by Glyn Johns, it was produced by Bill Szymczyk because the group wanted a more rock‑oriented sound instead of the country-rock feel of the first two albums.[2] It is the first Eagles album to feature guitarist Don Felder.", "One of These Nights is the fourth studio album by the Eagles, released in 1975. The record would become the Eagles' first number one album on Billboard's album chart in July that year, and yielded three Top 10 singles. Its title song is the group's second number one single on the Billboard Hot 100.", "Hotel California is the fifth studio album by American rock band the Eagles, and is one of the best-selling albums of all time. The album became the band's best-selling album after Their Greatest Hits (1971–1975), with over 16 million copies sold in the U.S. alone and over 32 million copies sold worldwide.", "The Long Run is the sixth studio album by American rock group the Eagles. It was released in 1979, on Asylum in the United States and in the United Kingdom. This was the first Eagles album to feature Timothy B. Schmit, who had replaced founding member Randy Meisner and the last full studio album to feature Don Felder before his termination from the band in 2001.", "Long Road Out of Eden is the seventh studio album by American rock band the Eagles, released in 2007 on Lost Highway Records. Nearly six years in production, it is the band's first studio album since 1979's The Long Run. "]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        albumName.text = albums[albumIndex].capitalized
        labelName.text = labels[albumIndex]
        releaseDate.text = date[albumIndex]
        usChart.text = chart[albumIndex]
        detailImg.image = #imageLiteral(resourceName: "wholeBand")
        albumAbout.text = desc[albumIndex]
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
