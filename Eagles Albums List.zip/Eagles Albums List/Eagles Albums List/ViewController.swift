//
//  ViewController.swift
//  Eagles Albums List
//
//  Created by Keegan Davidson on 2/15/18.
//  Copyright © 2018 Keegan Davidson. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var albums = ["eagles", "desperado", "on the border", "one of these nights","hotel california", "the long run", "long road out of eden"]
    
    var albumNames = ["selfTitled", "desperado", "onTheBorder", "oneOfTheseNights","hotelCalifornia", "theLongRun", "longRoadOutOfEden"]
    
    var releaseYear = ["1972", "1973", "1974", "1975", "1976", "1979", "2007"]
    
    @IBOutlet weak var albumTable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        albumTable.delegate = self
        albumTable.dataSource = self
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return albums.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = albumTable.dequeueReusableCell(withIdentifier: "albumCell") as? albumTableViewCell
        
        var rowHeight = 100
        
        cell?.albumName?.text? = albums[indexPath.row].capitalized
        cell?.albumYear.text? = releaseYear[indexPath.row]
        cell?.albumPhoto.image = UIImage(named: albumNames[indexPath.row])
        
        
        return cell!
    }
    
    override func prepare(for seque: UIStoryboardSegue, sender: Any?) {
        
        if seque.identifier == "gotoIndividualAlbum" {
            let destination = seque.destination as? individualAlbumViewController
            destination?.albumIndex = (albumTable.indexPathForSelectedRow?.row)!
        }
    }
    
}
