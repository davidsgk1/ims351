//
//  ViewController.swift
//  Natural 20
//
//  Created by Keegan Davidson on 4/3/18.
//  Copyright © 2018 Keegan Davidson. All rights reserved.
//

import UIKit
import WatchConnectivity

class ViewController: UIViewController, WCSessionDelegate {
    
    //Set up functions
    var watchSession: WCSession!
    public func sessionDidBecomeInactive(_ session: WCSession) {
        print ("error in sessionDidBecomeInactive")
    }
    public func sessionDidDeactivate(_ session: WCSession) {
        print("error in SessionDidDeactivate")
    }
    public func session(_ session: WCSession, activationDidCompleteWith     activationState: WCSessionActivationState, error: Error?) {
        print("error in activationDidCompleteWith error")
    }
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        print(message)
    }
    
    //Connects from the storyboard
    @IBAction func diceTypeButton(_ sender: Any) {
        watchSession.sendMessage(["diceType":diceTypeSegmentedControl.selectedSegmentIndex], replyHandler: nil, errorHandler: nil)
    }
    @IBOutlet weak var diceTypeSegmentedControl: UISegmentedControl!
    @IBOutlet weak var rollResultLabel: UILabel!
    @IBAction func rollDiceButton(_ sender: Any) {
        var diceType = diceTypeSegmentedControl.selectedSegmentIndex
        
        if (diceType == 0) {
            diceType = 4
        }
        else if (diceType == 1) {
            diceType = 6
        }
        else if (diceType == 2) {
            diceType = 8
        }
        else if (diceType == 3) {
            diceType = 10
        }
        else if (diceType == 4 ) {
            diceType = 0
        }
        else if (diceType == 5) {
            diceType = 12
        }
        else if (diceType == 6) {
            diceType = 20
        }
        
        if (diceType > 0) {
            var roll = String(Int(arc4random_uniform(UInt32(diceType)) + 1))
            rollResultLabel.text = roll
        }
        else {
            var roll = String(Int(arc4random_uniform(UInt32(10))) * 10)
            rollResultLabel.text = roll
        }
    
    }
    
    
    //Setup/class functions
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        if(WCSession.isSupported()) {
            self.watchSession = WCSession.default
            self.watchSession.delegate = self
            self.watchSession.activate()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

