//
//  InterfaceController.swift
//  Natural 20 WatchKit Extension
//
//  Created by Keegan Davidson on 4/3/18.
//  Copyright © 2018 Keegan Davidson. All rights reserved.
//

import WatchKit
import Foundation
import WatchConnectivity


class InterfaceController: WKInterfaceController, WCSessionDelegate {
    
    var diceType = 0
    
    public func session(_ session: WCSession, activationDidCompleteWith     activationState: WCSessionActivationState, error: Error?) {
        print("error in activationDidCompleteWith error")
    }
    
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        var diceType = (message["diceType"]! as? Int)!
        diceRollResult.setText(String(diceType))
    }

    
    
    var watchSession: WCSession!
    
    @IBOutlet var diceRollResult: WKInterfaceLabel!
    @IBAction func rollDiceButton() {
        if (diceType == 0) {
            diceType = 4
        }
        else if (diceType == 1) {
            diceType = 6
        }
        else if (diceType == 2) {
            diceType = 8
        }
        else if (diceType == 3) {
            diceType = 10
        }
        else if (diceType == 4 ) {
            diceType = 0
        }
        else if (diceType == 5) {
            diceType = 12
        }
        else if (diceType == 6) {
            diceType = 20
        }
        
        print(diceType)
        
        if (diceType != 0) {
            var roll = String(Int(arc4random_uniform(UInt32(diceType))) + 1)
            diceRollResult.setText(roll)
        }
        else {
            var roll = String(Int(arc4random_uniform(UInt32(10))) * 10)
            diceRollResult.setText(roll)
        }
        
    }
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        
        if(WCSession.isSupported()) {
            self.watchSession = WCSession.default
            self.watchSession.delegate = self
            self.watchSession.activate()
        }
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
